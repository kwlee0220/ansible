#!	/bin/bash

ros2 launch rosbridge_server rosbridge_websocket_launch.xml
