#!	/bin/bash

ros2 launch moveit_resources_panda_moveit_config demo.launch.py
