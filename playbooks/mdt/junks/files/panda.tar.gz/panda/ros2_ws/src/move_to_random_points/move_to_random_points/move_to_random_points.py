#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.action import ActionClient
import random

from std_msgs.msg import Header
from geometry_msgs.msg import Pose, Point, Quaternion
from moveit_msgs.action import MoveGroup

    
FRAME_ID = "panda_link0"
END_EFFECTOR_LINK = "panda_link8"


class MoveToRandomPointsNode(Node):
    """
    5개의 임의의 지점을 돌아가면서 Panda 로봇 팔을 MoveIt2를 이용하여 움직이는 노드
    """
    
    def __init__(self):
        super().__init__('move_to_random_points')
        
        # 파라미터 설정
        self.declare_parameter('planning_group', 'panda_arm')
        self.declare_parameter('num_waypoints', 5)
        self.declare_parameter('position_tolerance', 0.01)  # 미터 단위
        self.declare_parameter('orientation_tolerance', 0.01)  # 라디안 단위
        self.declare_parameter('planning_time', 10.0)  # 계획 시간 증가
        self.declare_parameter('max_velocity_scaling', 0.1)  # 속도 스케일링 감소
        self.declare_parameter('max_acceleration_scaling', 0.1)
        
        # 파라미터 가져오기
        self.planning_group = self.get_parameter('planning_group').value
        self.num_waypoints = self.get_parameter('num_waypoints').value
        self.position_tolerance = self.get_parameter('position_tolerance').value
        self.orientation_tolerance = self.get_parameter('orientation_tolerance').value
        self.planning_time = self.get_parameter('planning_time').value
        self.max_velocity_scaling = self.get_parameter('max_velocity_scaling').value
        self.max_acceleration_scaling = self.get_parameter('max_acceleration_scaling').value
        
        # MoveIt2 설정
        self.callback_group = ReentrantCallbackGroup()
        
        # MoveGroup 액션 클라이언트 생성
        self.move_group_client = ActionClient(
            self,
            MoveGroup,
            'move_action',
            callback_group=self.callback_group
        )
        
        # 타이머 설정 (5초마다 다음 포즈로 이동)
        self.timer = self.create_timer(
            5.0,  # 5초마다 다음 포즈로 이동
            self.move_to_next_pose,
            callback_group=self.callback_group
        )
        
        # Panda 로봇 팔 작업 공간 한계 (미터 단위)
        self.x_min, self.x_max = 0.3, 0.5  # 작업 공간 범위 축소
        self.y_min, self.y_max = -0.2, 0.2  # 작업 공간 범위 축소
        self.z_min, self.z_max = 0.3, 0.5  # 작업 공간 범위 축소
        
        # 현재 목표 포인트 인덱스
        self.current_goal_idx = 0
        
        # 임의 웨이포인트 생성
        waypoints = self.generate_random_waypoints(self.num_waypoints)
        # 웨이포이트로부터 goal를 생성
        self.goals = [self.create_move_group_goal(waypoint) for waypoint in waypoints]

        # MoveIt2 인터페이스 초기화
        self.get_logger().info('MoveIt2 인터페이스 초기화 중...')
        self.wait_for_move_action_server()
        
        self.get_logger().info('MoveToRandomPoints 노드 초기화 완료')
        self.get_logger().info(f'{self.num_waypoints}개의 임의 지점 생성 완료')
    
    def wait_for_move_action_server(self):
        """MoveGroup 액션 서버 연결 대기"""
        self.get_logger().info('MoveGroup 액션 서버에 연결 중...')
        
        # 60초 동안 서버 연결 시도
        server_connected = self.move_group_client.wait_for_server(timeout_sec=10.0)
        
        if server_connected:
            self.get_logger().info('MoveGroup 액션 서버에 연결되었습니다.')
            self.moveit_ready = True
        else:
            self.get_logger().error('MoveGroup 액션 서버에 연결할 수 없습니다.')
            self.moveit_ready = False
    
    def generate_random_waypoints(self, num_points):
        """로봇 작업 공간 내에서 임의의 웨이포인트 생성"""
        waypoints = []
        
        # 기본 방향 (그리퍼가 아래를 향하도록)
        orientation = Quaternion(x=1.0, y=0.0, z=0.0, w=0.0)
        
        for i in range(num_points):
            # 작업 공간 내에서 임의의 위치 생성
            x = random.uniform(self.x_min, self.x_max)
            y = random.uniform(self.y_min, self.y_max)
            z = random.uniform(self.z_min, self.z_max)
            
            pose = Pose()
            pose.position = Point(x=x, y=y, z=z)
            pose.orientation = orientation
            
            waypoints.append(pose)
            self.get_logger().info(f'웨이포인트 {i+1}: 위치=({x:.2f}, {y:.2f}, {z:.2f})')
            
        return waypoints
        
    def create_move_group_goal(self, target_pose):
        """MoveGroup 액션 목표 생성"""
        from moveit_msgs.msg import MotionPlanRequest, WorkspaceParameters, Constraints, JointConstraint
        from moveit_msgs.msg import PositionConstraint, OrientationConstraint, BoundingVolume
        from moveit_msgs.action import MoveGroup
        from shape_msgs.msg import SolidPrimitive
        from geometry_msgs.msg import Vector3
        
        goal = MoveGroup.Goal()
        
        # 계획 요청 설정
        motion_req = MotionPlanRequest()
        motion_req.workspace_parameters.header.frame_id = "panda_link0" # 작업공간 좌표계 설정
        motion_req.workspace_parameters.header.stamp = self.get_clock().now().to_msg()
        
        # 작업 공간 범위 확장 (더 넓은 범위에서 계획 시도)
        motion_req.workspace_parameters.min_corner.x = self.x_min - 0.2
        motion_req.workspace_parameters.min_corner.y = self.y_min - 0.2
        motion_req.workspace_parameters.min_corner.z = self.z_min - 0.2
        motion_req.workspace_parameters.max_corner.x = self.x_max + 0.2
        motion_req.workspace_parameters.max_corner.y = self.y_max + 0.2
        motion_req.workspace_parameters.max_corner.z = self.z_max + 0.2
        
        motion_req.start_state.is_diff = True   # 이전 상태와의 차이를 기반으로 시작 상태 설정
        motion_req.group_name = self.planning_group

        # 위치 제약
        sphere = SolidPrimitive(type=SolidPrimitive.SPHERE, dimensions=[self.position_tolerance])
        pose_constraint = PositionConstraint(
            header=Header(frame_id=FRAME_ID),
            link_name=END_EFFECTOR_LINK,
            target_point_offset=Vector3(x=0.0, y=0.0, z=0.0),
            constraint_region=BoundingVolume(primitives=[sphere], primitive_poses=[target_pose]),
            weight=1.0
        )

        # 방향 제약
        orientation_constraint = OrientationConstraint(
            header=Header(frame_id=FRAME_ID),
            orientation=target_pose.orientation,
            link_name=END_EFFECTOR_LINK,
            absolute_x_axis_tolerance=self.orientation_tolerance,
            absolute_y_axis_tolerance=self.orientation_tolerance,
            absolute_z_axis_tolerance=self.orientation_tolerance,
            weight=1.0
        )

        # 제약 조건 추가
        motion_req.goal_constraints = [Constraints(
            position_constraints=[pose_constraint],
            orientation_constraints=[orientation_constraint]
        )]
        
        # 계획 ID 및 파라미터 설정 - 성공률 향상을 위한 조정
        # 다른 플래너 시도 (RRTConnect, PRM, RRT)
        # planners = ["RRTConnect", "PRM", "RRT"]
        # planner_idx = self.current_goal_idx % len(planners)  # 웨이포인트마다 다른 플래너 사용
        motion_req.planner_id = "RRTConnect"
        
        # 계획 시간 및 시도 횟수 증가
        motion_req.allowed_planning_time = 15.0  # 계획 시간 증가
        motion_req.max_velocity_scaling_factor = 0.07  # 속도 더 감소
        motion_req.max_acceleration_scaling_factor = 0.07  # 가속도 더 감소
        motion_req.num_planning_attempts = 30  # 계획 시도 횟수 증가
        
        goal.request = motion_req
        goal.planning_options.planning_scene_diff.robot_state.is_diff = True
        goal.planning_options.plan_only = False
        
        return goal
    
    def handle_move_group_response(self, future):
        """MoveGroup 액션 응답 처리"""
        try:
            goal_handle = future.result()
            
            if not goal_handle.accepted:
                self.get_logger().error('이동 요청이 거부되었습니다.')
                self.current_goal_idx += 1
                return
                
            self.get_logger().info('이동 요청이 수락되었습니다. 결과 대기 중...')
            
            # 결과 대기
            result_future = goal_handle.get_result_async()
            result_future.add_done_callback(self.handle_move_group_result)
            
        except Exception as e:
            self.get_logger().error(f'응답 처리 중 오류 발생: {e}')
            self.current_goal_idx += 1
    
    def handle_move_group_result(self, future):
        """MoveGroup 액션 결과 처리"""
        try:
            response = future.result()
            
            if response and response.result:
                result = response.result
                
                # 결과 상태 확인
                if response.status == 1:  # 성공
                    self.get_logger().info('이동 성공')
                    self.current_goal_idx += 1
                else:
                    self.get_logger().error(f'이동 실패: 상태 코드 {response.status}')
                    
                    # 상태 코드에 따른 처리
                    if response.status == 4:  # 계획 실패
                        self.get_logger().warn('계획 실패. 다른 웨이포인트로 이동합니다.')
                        # 현재 웨이포인트를 건너뛰고 다음으로 이동
                        self.current_goal_idx += 1
                        # 잠시 대기 후 다시 시도 (oneshot 대신 일반 타이머 사용)
                        self.create_timer(2.0, lambda: self.retry_move(), callback_group=self.callback_group)
                    else:
                        # 다른 오류는 다음 웨이포인트로 이동
                        self.current_goal_idx += 1
            else:
                self.get_logger().error('이동 실패: 결과가 없음')
                self.current_goal_idx += 1
                
        except Exception as e:
            self.get_logger().error(f'결과 처리 중 오류 발생: {e}')
            self.current_goal_idx += 1
    
    def move_to_next_pose(self):
        """다음 웨이포인트로 이동"""
        if not self.moveit_ready:
            self.get_logger().warn('MoveIt2가 초기화되지 않았습니다. 로봇 제어는 수행되지 않습니다.')
            self.wait_for_move_action_server()
            return
        
        # 현재 인덱스가 범위를 벗어나면 처음으로 돌아감
        if self.current_goal_idx >= len(self.goals):
            self.current_goal_idx = 0
        
        target_goal = self.goals[self.current_goal_idx]
        target_pose = target_goal.request.goal_constraints[0] \
                                        .position_constraints[0] \
                                        .constraint_region \
                                        .primitive_poses[0]
        
        self.get_logger().info(f'웨이포인트 {self.current_goal_idx + 1}/{len(self.goals)}로 이동 중')
        self.get_logger().info(f'목표 위치: ({target_pose.position.x:.2f}, {target_pose.position.y:.2f}, {target_pose.position.z:.2f})')
        
        try:
            # 이동 요청 전송
            self.get_logger().info('이동 요청 전송 중...')
            future = self.move_group_client.send_goal_async(target_goal)
            future.add_done_callback(self.handle_move_group_response)
            
        except Exception as e:
            print('--------------------------------')
            self.get_logger().error(f'이동 요청 중 오류 발생: {e}')
            # 오류 발생 시 다음 웨이포인트로 이동
            self.current_goal_idx += 1
            # 잠시 대기 후 다시 시도 (oneshot 대신 일반 타이머 사용)
            self.create_timer(2.0, lambda: self.retry_move(), callback_group=self.callback_group)
    
    def retry_move(self):
        """이전 이동 실패 후 재시도"""
        # 타이머 취소
        self.timer.cancel()
        # 다음 웨이포인트로 이동
        self.move_to_next_pose()


def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = MoveToRandomPointsNode()
        
        # 멀티스레드 실행자 사용
        executor = MultiThreadedExecutor()
        executor.add_node(node)
        
        try:
            node.get_logger().info('Panda 로봇 팔 임의 이동 시작...')
            executor.spin()
        except KeyboardInterrupt:
            node.get_logger().info('사용자에 의해 중단됨')
        finally:
            executor.shutdown()
            node.destroy_node()
    except Exception as e:
        print(f'노드 실행 중 오류 발생: {e}')
    finally:
        rclpy.shutdown()


if __name__ == '__main__':
    main()
