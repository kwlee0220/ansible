#!	/bin/bash

source ros2_ws/install/setup.bash && ros2 run move_to_random_points move_to_random_points
