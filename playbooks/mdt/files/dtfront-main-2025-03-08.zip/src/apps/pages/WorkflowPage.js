import { ReactFlowProvider } from "@xyflow/react";
import ModalAddWorkflow from "apps/components/modal/modal_add_workflow";
import useDialog from "apps/components/modal/useDialog";
import useModal from "apps/components/modal/useModal";
import TreeView from "apps/components/Tree/TreeView";
import PropertyPanel from "apps/components/Workflow/comps/PropertyPanel";
import Workflow from "apps/components/Workflow/Workflow";
import WorkflowTaskItem from "apps/components/Workflow/WorkflowTaskItem";
import {
  TreeItemType,
  useConvert,
  useGenesisDataManager,
} from "apps/datas/definedData";
import useGlobalData from "apps/datas/useGlobalData";
import useRequestManager from "apps/utils/request_manager";
import UtilManager from "apps/utils/util_manager";
import clsx from "classnames";
import { useEffect, useRef, useState } from "react";
import { add_workflow, start_workflow, get_workflow_template_all, get_workflow } from "apps/remote/urls";
import ModalWorkflowTemplates from "apps/components/modal/modal_workflow_templates";
import ModalWorkflowList from "apps/components/modal/modal_workflow_list";

const WorkflowPage = () => {
  const projectFlowRef = useRef();

  const { GET_NODE_ORDER } = UtilManager();
  const modalAddWorkflow = useModal();
  const modalWorkflowTemplates = useModal();
  const modalWorkflowList = useModal();
  const { openDialog } = useDialog();
  const { GET_TASKLIST } = useGenesisDataManager();
  const {
    CONVERT_MDTLIST_TO_TREELIST,
    CREATE_TREEITEM,
    CONVERT_INNER_ELEMENT_TO_TREELIST,
  } = useConvert();
  const { instanceList } = useGlobalData();

  //#region 데이터 조회

  const {
    REQ_Node_SubModel_GET,
    REQ_Workflow_START,
    REQ_Workflow_ADD,
    REQ_Workflow_GET,
    REQ_Workflow_GET_ALL
  } = useRequestManager();

  const fetchSubModel = async (url, id) => {
    const encodeID = btoa(id);
    const path = url + "/submodels/" + encodeID + "?$value";

    let result = await REQ_Node_SubModel_GET({
      url: path,
    });

    let resultlist = [];

    if (result && result.submodelElements) {
      resultlist = result.submodelElements;
    }

    return resultlist;
  };

  const [addflow, setAddflow] = useState();

  const fetchAddWorkflow = async (workflow) => {
    console.log("******************** fetchAddWorkflow ", workflow);
    let result = await REQ_Workflow_ADD(workflow);
    console.log("register workflow to MDTI Manager result:", result);
  };

  const fetchExecWorkflow = async (workflow) => {
    console.log("********************* Starting workflow execution 2:", workflow);
    
    if (!workflow || !workflow.id) {
      console.error("Invalid workflow object:", workflow);
      return;
    }

    try {
        let r = await REQ_Workflow_GET(workflow.id);
        console.log("get_workflow with id(" + workflow.id + "): ", r);

        r = await REQ_Workflow_GET_ALL();
        console.log("get_workflow_all:", r);

      const result = await REQ_Workflow_START(workflow.id);
      console.log("Workflow execution successful:", result);
      openDialog({
        title: "워크플로우 실행",
        message: "워크플로우 실행이 시작되었습니다.",
        type: "alert"
      });
    } catch (error) {
      console.error("Workflow execution failed:", error);
      openDialog({
        title: "워크플로우 실행 오류",
        message: `워크플로우 실행 중 오류가 발생했습니다: ${error.message}`,
        type: "alert"
      });
    }
  };


  //#endregion

  //#region 컴포넌트 Accordion

  const [expandTask, setExpandTask] = useState(true);
  const [expandMDT, setExpandMDT] = useState(true);

  //#endregion

  //#region 리스트 관리

  const [tasklist, setTasklist] = useState([]);
  const [mdtlist, setMdtlist] = useState([]);

  const initData = () => {
    let list = GET_TASKLIST();

    setTasklist(list);

    const treelist = CONVERT_MDTLIST_TO_TREELIST(instanceList);

    setMdtlist(treelist);
  };

  //#endregion
  const fileInputRef = useRef();

  const handleOpenFile = () => {
    fileInputRef.current.click(); // 파일 입력 요소를 클릭하여 다이얼로그 띄우기
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0]; // 선택한 파일들

    if (file) {
      const reader = new FileReader();

      reader.onload = (e) => {
        let result = e.target.result;

        if (projectFlowRef) {
          projectFlowRef.current.onLoadFlowData(result);
        }
      };

      reader.readAsText(file);
    }
  };

  const onClickClear = () => {
    if (projectFlowRef) {
      projectFlowRef.current.onClearFlow();
    }
  };

  const onClickMakeScript = () => {
    if (projectFlowRef) {
      const resp = projectFlowRef.current.onLoadWorkflowDescriptor();

      if (resp.nodes.length > 0 && resp.edges.length > 0) {
        const flow = GET_NODE_ORDER(resp.nodes, resp.edges);
        let tasklist = [];

        flow.forEach((id) => {
          let node = resp.nodes.find((inner) => inner.id === id);

          if (node && node.type !== "property") {
            let task = node.data.item;

            tasklist.push(task);
          }
        });

        setAddflow(tasklist);

        console.log(tasklist);

        modalAddWorkflow.toggleModal();
      } else {
        openDialog({
          title: "Flow 저장",
          message:
            "작업간의 Flow가 존재하지 않습니다. Flow를 연결한 후 등록해주세요.",
          type: "alert",
        });
      }
    }
  };

  const onClickLoad = () => {
    handleOpenFile();
  };

  const onClickStart = () => {
    modalWorkflowTemplates.toggleModal();
  };

  const onClickListWorkflows = () => {
    modalWorkflowList.toggleModal();
  };

  const handleSelectTemplate = async (template) => {
    try {
      console.log("Selected template:", template);
      const result = await REQ_Workflow_START(template.id);
      if (result) {
        openDialog({
          title: "워크플로우 실행",
          message: "워크플로우가 성공적으로 시작되었습니다.",
          type: "alert",
        });
      } else {
        openDialog({
          title: "워크플로우 실행 실패",
          message: "워크플로우를 시작하는데 실패했습니다.",
          type: "alert",
        });
      }
    } catch (error) {
      console.error("워크플로우 실행 오류:", error);
      openDialog({
        title: "워크플로우 실행 오류",
        message: `오류: ${error.message || "알 수 없는 오류가 발생했습니다."}`,
        type: "alert",
      });
    }
  };

  const onClickSave = () => {
    if (projectFlowRef) {
      openDialog({
        title: "Flow 저장",
        message: "Flow를 저장하시겠습니까?",
        type: "confirm",
        confirmHandler: () => {
          projectFlowRef.current.onSaveFlowData();
        },
      });
    }
  };

  const onClickNode = async (node) => {
    if (node.type === TreeItemType.SubModel) {
      let parent = node.parent;
      let data = node.data;

      if (parent && parent.data && data) {
        let endpoint = parent.data.baseEndpoint;
        let id = data.id;

        let result = await fetchSubModel(endpoint, id);

        let nodeItem = CONVERT_INNER_ELEMENT_TO_TREELIST(result, node);

        node.children = nodeItem;
      }

      console.log(node);
    }
  };

  useEffect(() => {
    initData();
  }, []);

  return (
    <div className="main-content px-3">
      <div className="page-header mt-2 border rounded workflow-header">
        <h4 className="me-2 mb-0" style={{ width: "420px" }}>
          Workflow
        </h4>
        <div className="flex-group">
          <div className="btn-toolkit" onClick={onClickStart}>
            <i className="ph-play me-2"></i>
            Start
          </div>
          <div className="btn-toolkit" onClick={onClickListWorkflows}>
            <i className="ph-list-bullets me-2"></i>
            List Workflows
          </div>
        </div>
        <div className="flex-group ms-auto">
          <input
            type="file"
            ref={fileInputRef}
            style={{ display: "none" }} // 숨겨진 파일 입력
            onChange={handleFileChange}
          />
          <div className="btn-toolkit" onClick={onClickClear}>
            <i className="ph-eraser me-2"></i>
            Clear
          </div>
          <div className="btn-toolkit" onClick={onClickLoad}>
            <i className="ph-folder-notch-open me-2"></i>
            Load
          </div>
          <div className="btn-toolkit" onClick={onClickSave}>
            <i className="ph-floppy-disk me-2"></i>
            Save
          </div>
        </div>
      </div>

      <div className="pnl-workflow">
        <ReactFlowProvider>
          <div className="card pnl-workflow-components">
            <div className="accordion">
              <div className="accordion-item">
                <h2 className="accordion-header">
                  <button
                    className={clsx(
                      "accordion-button fw-semibold",
                      expandTask ? "" : "collapsed"
                    )}
                    type="button"
                    onClick={() => setExpandTask(!expandTask)}
                  >
                    Task
                  </button>
                </h2>
                <div
                  className={clsx(
                    "accordion-collapse collapse",
                    expandTask ? "show" : ""
                  )}
                >
                  <div className="accordion-body">
                    {tasklist &&
                      tasklist.map((item, index) => {
                        return <WorkflowTaskItem key={index} item={item} />;
                      })}
                  </div>
                </div>
              </div>
            </div>

            <div className="accordion mt-3">
              <div className="accordion-item">
                <h2 className="accordion-header">
                  <button
                    className={clsx(
                      "accordion-button fw-semibold",
                      expandMDT ? "" : "collapsed"
                    )}
                    type="button"
                    onClick={() => setExpandMDT(!expandMDT)}
                  >
                    MDT Instance
                  </button>
                </h2>
                <div
                  className={clsx(
                    "accordion-collapse collapse",
                    expandMDT ? "show" : ""
                  )}
                >
                  <div className="accordion-body p-1 pnl-ctr-mdtinstance">
                    <TreeView list={mdtlist} clickNode={onClickNode}></TreeView>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Workflow ref={projectFlowRef}></Workflow>
        </ReactFlowProvider>
      </div>

      <ModalAddWorkflow
        open={modalAddWorkflow.open}
        closeModal={modalAddWorkflow.toggleModal}
        origin={addflow}
        handleAdd={fetchAddWorkflow}
        handleExec={fetchExecWorkflow}
      ></ModalAddWorkflow>

      <ModalWorkflowTemplates
        open={modalWorkflowTemplates.open}
        closeModal={modalWorkflowTemplates.toggleModal}
        onSelectTemplate={handleSelectTemplate}
      />

      <ModalWorkflowList
        open={modalWorkflowList.open}
        closeModal={modalWorkflowList.toggleModal}
      />
    </div>
  );
};

export default WorkflowPage;
