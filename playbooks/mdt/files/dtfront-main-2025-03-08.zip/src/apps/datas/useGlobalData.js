import { shallowEqual, useSelector } from "react-redux";

const useGlobalData = () => {
  const {
    userID,
    isLogin,
    loginUser,
    instanceList,
    workflowList,
    pauseInstance,
  } = useSelector(
    (state) => ({
      userID: state.auth.id,
      isLogin: state.auth.isLoggedIn,
      loginUser: state.auth.user,
      instanceList: state.datalist.instanceList,
      workflowList: state.datalist.workflowList,
      pauseInstance: state.datalist.pauseInstance,
    }),
    shallowEqual
  );

  return {
    userID,
    isLogin,
    loginUser,
    instanceList,
    workflowList,
    pauseInstance,
  };
};

export default useGlobalData;
