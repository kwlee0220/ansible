import { combineReducers } from "@reduxjs/toolkit";

import { dialogSlice } from "./dialog";
import { authSlice } from "./auth";
import { datalistSlice } from "./datalist";

export const rootReducer = combineReducers({
  auth: authSlice.reducer,
  dialog: dialogSlice.reducer,
  datalist: datalistSlice.reducer,
});
