import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { get_instance_all } from "apps/remote/urls";

const initialState = {
  pauseInstance: false,
  instanceList: [],
  workflowList: [],
};

export const fetchInstanceList = createAsyncThunk(
  "datalist/instance",
  async () => {
    const resp = await get_instance_all();
    const data = resp.data;

    return data;
  }
);

export const datalistSlice = createSlice({
  name: "datalist",
  initialState,
  reducers: {
    setInstancePause: (state, action) => {
      console.log(action.payload);
      const pause = action.payload;

      if (pause) {
        state.pauseInstance = true;
      } else {
        state.pauseInstance = false;
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchInstanceList.fulfilled, (state, action) => {
        if (action.payload) {
          state.instanceList = action.payload;
        } else {
          state.instanceList = [];
        }
      })
      .addCase(fetchInstanceList.rejected, (state, action) => {
        state.instanceList = [];
      });
  },
});

export const { setInstancePause } = datalistSlice.actions;
