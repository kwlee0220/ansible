import { closeDialogCall, openDialogCall } from "apps/store/reducers/dialog";
import { useDispatch, useSelector } from "react-redux";

const useDialog = () => {
  const dispatch = useDispatch();
  const { type, show, message, title, confirmHandler, denyHandler } =
    useSelector((state) => ({
      type: state.dialog.type,
      show: state.dialog.show,
      message: state.dialog.message,
      title: state.dialog.title,
      confirmHandler: state.dialog.confirmHandler,
      denyHandler: state.dialog.denyHandler,
    }));

  const open = (param) => {
    dispatch(openDialogCall(param));
  };

  const openD = (param) => {
    dispatch(openDialogCall(param));
  };

  const openDialog = (param) => {
    dispatch(openDialogCall(param));
  };

  const close = () => {
    dispatch(closeDialogCall());
  };

  return {
    type,
    show,
    message,
    title,
    confirmHandler,
    denyHandler,
    open,
    openD,
    openDialog,
    close,
  };
};

export default useDialog;
