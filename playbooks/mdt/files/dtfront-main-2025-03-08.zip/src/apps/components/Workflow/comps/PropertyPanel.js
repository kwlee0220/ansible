import EmptyList from "apps/components/EmptyList";
import ModalADDVariable from "apps/components/modal/modal_add_variable";
import useDialog from "apps/components/modal/useDialog";
import useModal from "apps/components/modal/useModal";
import { TaskType } from "apps/datas/definedData";
import UtilManager from "apps/utils/util_manager";
import { useEffect, useState } from "react";

const PropertyPanel = ({ origin, handleModify, closePanel }) => {
  const { CloneDeep, CHECK_EXIST } = UtilManager();
  const { openDialog } = useDialog();
  const modalADDVariable = useModal();

  const [nodedata, setNodeData] = useState();
  const [isInOutExpand, setIsInOutExpand] = useState(false);

  const [dependencies, setDependencies] = useState([]);
  const [inputs, setInputs] = useState([]);
  const [outputs, setOutputs] = useState([]);
  const [options, setOptions] = useState([]);

  const handleChangeInput = (e) => {
    const { name, value } = e.target;

    setNodeData({
      ...nodedata,
      [name]: value,
    });
  };

  const handleAddVariable = (item) => {
    let success = false;

    switch (item.kind) {
      case "INPUT":
        if (!CHECK_EXIST(inputs, item.name)) {
          success = true;
          setInputs([...inputs, item]);
        }
        break;
      case "OUTPUT":
        if (!CHECK_EXIST(outputs, item.name)) {
          success = true;
          setOutputs([...outputs, item]);
        }
        break;
    }

    if (success) {
      modalADDVariable.toggleModal();
    } else {
      openDialog({
        title: "Input/Output 추가 에러",
        message: "중복된 이름을 사용할 수 없습니다.",
        type: "alert",
      });
    }
  };

  const handleRemoveVariable = (item, index) => {
    switch (item.kind) {
      case "INPUT":
        let input = [...inputs];
        input.splice(index, 1);
        setInputs(input);
        break;
      case "OUTPUT":
        let output = [...outputs];
        output.splice(index, 1);
        setOutputs(output);
        break;
    }
  };

  const onClickModify = () => {
    let data = { ...nodedata };

    let lst_variable = [...inputs, ...outputs];
    data.variables = lst_variable;

    handleModify(origin.id, data);
  };

  const convertVariable = (list) => {
    let lst_input = [];
    let lst_output = [];

    list.forEach((element) => {
      switch (element.kind) {
        case "INPUT":
          lst_input.push(element);
          break;
        case "OUTPUT":
          lst_output.push(element);
          break;
      }
    });

    setInputs(lst_input);
    setOutputs(lst_output);
  };

  const convertData = (info) => {
    let data = CloneDeep(info.data.item);

    let lst_variable = [...data.variables];

    convertVariable(lst_variable);

    checkType(data.type);
    setNodeData(data);
  };

  const checkType = (type) => {
    let enabled = false;

    switch (type) {
      case TaskType.SET:
      case TaskType.COPY:
        enabled = false;
        break;
      case TaskType.PROGRAM:
      case TaskType.HTTP:
      case TaskType.JSLT:
      case TaskType.AAS:
        enabled = true;
        break;
      default:
        break;
    }

    setIsInOutExpand(enabled);
  };

  useEffect(() => {
    if (origin) {
      convertData(origin);
    }
  }, [origin]);

  return (
    <>
      <div className="card card-property">
        <div className="card-header flex-ycenter p-0">
          <div className="header-icon">
            <i className="ph-app-window"></i>
          </div>
          <h6 className="mb-0">속성</h6>
          <div className="ms-auto">
            <button
              type="button"
              className="btn btn-link btn-icon text-default"
              onClick={() => closePanel(false)}
            >
              <i className="ph-x"></i>
            </button>
          </div>
        </div>
        <div className="card-body">
          <div className="row mb-2">
            <label className="col-form-label col-4">Type</label>
            <label className="col-form-label col-8">
              {nodedata ? nodedata.type : ""}
            </label>
          </div>
          <div className="row mb-2">
            <label className="col-form-label col-4">ID</label>
            <div className="col-8">
              <input
                type="text"
                className="form-control"
                name="id"
                value={nodedata ? nodedata.id : ""}
                onChange={handleChangeInput}
              ></input>
            </div>
          </div>
          <div className="row mb-2">
            <label className="col-form-label col-4">Name</label>
            <div className="col-8">
              <input
                type="text"
                className="form-control"
                name="name"
                value={nodedata ? nodedata.name : ""}
                onChange={handleChangeInput}
              ></input>
            </div>
          </div>
          <div className="row mb-2 d-none">
            <label className="col-form-label col-4">Description</label>
            <div className="col-8">
              <input
                type="text"
                className="form-control"
                name="description"
                value={nodedata ? nodedata.description : ""}
                onChange={handleChangeInput}
              ></input>
            </div>
          </div>
          <div className="py-2 d-none">
            <div className="fw-bold mb-2 flex-ycenter">
              <span>Dependencies</span>
              <input
                type="text"
                className="form-control ms-auto me-2 width-150"
              ></input>
              <button className="btn btn-info btn-icon">
                <i className="ph-plus"></i>
              </button>
            </div>
            {dependencies.length > 0 ? (
              <div className=""></div>
            ) : (
              <EmptyList message={"없음"}></EmptyList>
            )}
          </div>
          <div className="py-2">
            <div className="fw-bold mb-2 flex-ycenter">
              <span>Input</span>
              {isInOutExpand ? (
                <button
                  className="btn btn-info btn-icon ms-auto"
                  onClick={modalADDVariable.toggleModal}
                >
                  <i className="ph-plus"></i>
                </button>
              ) : (
                <></>
              )}
            </div>
            {inputs.length > 0 ? (
              <div className="list-group ">
                {inputs.map((item, index) => (
                  <li key={index} className="list-group-item flex-ycenter ">
                    <span>{item.name}</span>
                    <button
                      className="btn btn-sm btn-transparent text-danger btn-icon ms-auto"
                      onClick={() => handleRemoveVariable(item, index)}
                    >
                      <i className="ph-x"></i>
                    </button>
                  </li>
                ))}
              </div>
            ) : (
              <EmptyList message={"없음"}></EmptyList>
            )}
          </div>
          <div className="py-2">
            <div className="fw-bold mb-2 flex-ycenter">
              <span>Output</span>
            </div>
            {outputs.length > 0 ? (
              <div className="list-group ">
                {outputs.map((item, index) => (
                  <li key={index} className="list-group-item flex-ycenter ">
                    <span>{item.name}</span>
                    <button
                      className="btn btn-sm btn-transparent text-danger btn-icon ms-auto"
                      onClick={() => handleRemoveVariable(item, index)}
                    >
                      <i className="ph-x"></i>
                    </button>
                  </li>
                ))}
              </div>
            ) : (
              <EmptyList message={"없음"}></EmptyList>
            )}
          </div>
          <div className="py-2 d-none">
            <div className="fw-bold mb-2 flex-ycenter">
              <span>Options</span>
              <button className="btn btn-info btn-icon ms-auto">
                <i className="ph-plus"></i>
              </button>
            </div>
            {options.length > 0 ? (
              <div className="border rounded py-2"></div>
            ) : (
              <EmptyList message={"없음"}></EmptyList>
            )}
          </div>
        </div>
        <div className="card-footer flex-ycenter p-2">
          <button className="btn btn-default ms-auto" onClick={onClickModify}>
            적용
          </button>
        </div>
      </div>

      <ModalADDVariable
        open={modalADDVariable.open}
        closeModal={modalADDVariable.toggleModal}
        handleAdd={handleAddVariable}
      ></ModalADDVariable>
    </>
  );
};

export default PropertyPanel;
