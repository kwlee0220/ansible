import { Handle, Position } from "@xyflow/react";
import { memo, useEffect } from "react";

const NodeProperty = ({ id, data, selected }) => {
  const convertData = (data) => {
    console.log("Node", data);
  };

  useEffect(() => {
    if (data) {
      convertData(data);
    }
  }, [data]);

  return (
    <div className="pnl-property-node">
      <Handle type="target" position={Position.Left}></Handle>
      <div>{data?.label || ""}</div>
      <Handle type="source" position={Position.Right}></Handle>
    </div>
  );
};

export default memo(NodeProperty);
