import {
  applyEdgeChanges,
  applyNodeChanges,
  Background,
  ConnectionLineType,
  Controls,
  MarkerType,
  ReactFlow,
  useEdgesState,
  useNodesState,
  useReactFlow,
} from "@xyflow/react";
import moment from "moment";

import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import useDataManager from "apps/utils/data_manager";
import TreeView from "../Tree/TreeView";
import {
  TaskType,
  useGenesisDataManager,
  WorkflowNodeType,
} from "apps/datas/definedData";
import ModalNode from "../modal/modal_node";
import useModal from "../modal/useModal";
import PropertyPanel from "./comps/PropertyPanel";
import UtilManager from "apps/utils/util_manager";

const getId = () => {
  let name = "node_" + moment().valueOf();

  return name;
};
const getLineID = () => {
  let name = "line_" + moment().valueOf();

  return name;
};

const edgeType = {};

const nodeInfo = {
  id: "",
  type: "",
  position: "",
  style: {},
  data: {
    label: "",
  },
};

const Workflow = forwardRef(({}, ref) => {
  const { GET_TASKLABEL, GET_NODETYPE } = useGenesisDataManager();
  const { IS_POSSIBLE_CONNECT, SET_DATA_CONNECT } = UtilManager();

  //#region 컴포넌트 Accordion
  const [expandProperty, setExpandProperty] = useState(false);

  const handleModifyProperty = (id, data) => {
    setNodes((nds) =>
      nds?.map((node) => {
        if (node.id === id) {
          return {
            ...node,
            data: {
              ...node.data,
              item: data,
            },
          };
        }

        return node;
      })
    );

    setExpandProperty(false);
    setSelectedNode(null);
  };

  const handleExpandProperty = (view) => {
    setExpandProperty(view);
  };

  //#endregion

  //#region Tree 관련

  const { GET_DATA_SOURCE_TREE, GET_DATA_TARGET_TREE } = useDataManager();
  const [viewTree, setViewTree] = useState(false);

  //#endregion

  const reactFlowWrapper = useRef(null);

  useImperativeHandle(ref, () => ({
    onSaveFlowData,
    onLoadFlowData,
    onClearFlow,
    onLoadWorkflowDescriptor,
  }));

  const { getNode, getEdge, setViewport } = useReactFlow();

  const [nodes, setNodes] = useNodesState([]);
  const [edges, setEdges] = useEdgesState([]);
  const [reactFlowInstance, setReactFlowInstance] = useState(null);
  const [selectedNode, setSelectedNode] = useState();

  const [sourceTreeData, setSourceTreeData] = useState();
  const [targetTreeData, setTargetTreeData] = useState();

  /********************************
   *
   * Flow Data 관리 함수
   *
   **********************************/
  const onLoadWorkflowDescriptor = () => {
    return {
      nodes: nodes,
      edges: edges,
    };
  };

  const onClearFlow = useCallback(() => {
    setNodes([]);
    setEdges([]);
  }, [setNodes, setEdges]);

  const onSaveFlowData = useCallback(() => {
    if (reactFlowInstance) {
      const flow = reactFlowInstance.toObject();

      const contents = JSON.stringify(flow, null, 2);
      const blob = new Blob([contents], { type: "application/json" });

      // Blob URL 생성
      const url = URL.createObjectURL(blob);

      // 가상 a 태그 생성
      const link = document.createElement("a");
      link.href = url;
      link.download = `workflow_${moment().valueOf()}.json`; // 기본 파일명 지정

      // 클릭 이벤트로 다운로드 트리거
      document.body.appendChild(link);
      link.click();

      // URL과 태그 정리
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  }, [reactFlowInstance]);

  const onLoadFlowData = useCallback(
    (contents) => {
      const restoreFlow = async (contents) => {
        const flow = JSON.parse(contents);

        if (flow) {
          const { x = 0, y = 0, zoom = 1 } = flow.viewport;

          setNodes(flow.nodes || []);
          setEdges(flow.edges || []);
          setViewport({ x, y, zoom });
        }
      };

      restoreFlow(contents);
    },
    [setNodes, setViewport]
  );

  /********************************
   *
   * Node 다이얼로그 함수
   *
   **********************************/
  const getDefaultNodeData = (item) => {
    let label = "";

    if (item.type) {
      label = GET_TASKLABEL(item.type);
    } else {
      label = item.idShort;
    }

    let result = {
      label: label,
      item: item,
      onShowNodeSetting: onClickNodeSetting,
    };

    return result;
  };

  const onClickNodeSetting = (id, data) => {
    setSelectedNode({
      id: id,
      data: data,
    });

    setExpandProperty(true);
  };

  /********************************
   *
   * ReactFlow 이벤트 함수
   *
   **********************************/
  const onNodesChange = useCallback(
    (changes) => setNodes((nds) => applyNodeChanges(changes, nds)),
    [setNodes]
  );
  const onEdgesChange = useCallback(
    (changes) => setEdges((eds) => applyEdgeChanges(changes, eds)),
    [setEdges]
  );

  /**
   * 노드가 연결되었을 때 호출되는 함수
   */
  const onConnect = useCallback(
    (params) => {
      const { source, target, sourceHandle, targetHandle } = params;

      let node_source = getNode(source);
      let node_target = getNode(target);
      let data_task, data_property, target_handle;
      let target_id;

      console.log("===============================");
      console.log("Connect", params);

      console.log("Node", node_source, node_target);
      console.log("===============================");

      if (!IS_POSSIBLE_CONNECT(node_source, node_target)) {
        return;
      }

      /*
      const isHandleUsed = edges.some(
        (edge) => edge.target === target && edge.targetHandle === targetHandle
      );

      if (isHandleUsed) {
        return;
      }
        */

      if (node_source.type === "property") {
        target_id = target;
        data_task = node_target.data.item;
        data_property = node_source.data.item;
        target_handle = targetHandle;
      } else if (node_target.type === "property") {
        target_id = source;
        data_task = node_source.data.item;
        data_property = node_target.data.item;
        target_handle = sourceHandle;
      }

      SET_DATA_CONNECT(data_task, data_property, target_handle);

      setNodes((nds) =>
        nds?.map((node) => {
          if (node.id === target_id) {
            return {
              ...node,
              data: {
                ...node.data,
                item: data_task,
              },
            };
          }

          return node;
        })
      );

      const newLine = {
        ...params,
        id: getLineID(),
        type: ConnectionLineType.SmoothStep,
        markerEnd: {
          type: MarkerType.ArrowClosed,
          width: 10,
          height: 10,
          color: "#FF0072",
        },
        data: {
          label: "",
        },
        style: {
          strokeWidth: 1,
          stroke: "#FF0072",
        },
      };

      setEdges((eds) => eds?.concat(newLine));
    },
    [edges, setEdges]
  );

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();

      const item = event.dataTransfer.getData("application/reactflow");

      if (typeof item === "undefined" || !item) {
        return;
      }

      var info = null;

      try {
        info = JSON.parse(item);
      } catch {}

      if (info === null) {
        return;
      }

      const position = reactFlowInstance.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });
      const newNode = {
        id: getId(),
        type: GET_NODETYPE(info.type ? info.type : TaskType.Property),
        position,
        data: getDefaultNodeData(info),
      };

      console.log("workflow.onDrop:", info, newNode);
      setNodes((nds) => nds?.concat(newNode));
    },
    [reactFlowInstance]
  );

  const onNodeClick = (event, node) => {
    //console.log("Click Node", event, node);
  };

  const onEdgeDoubleClick = (event, edge) => {
    /*
    let source = null;
    let target = null;

    source = getNode(edge.source);
    target = getNode(edge.target);

    console.log("Source", source);
    console.log("Target", target);

    setSourceTreeData(GET_DATA_SOURCE_TREE);
    setTargetTreeData(GET_DATA_TARGET_TREE);

    setViewTree(true);
    */
  };

  const onClickCloseTree = () => {
    setViewTree(false);
  };

  useEffect(() => {}, [sourceTreeData, targetTreeData]);

  return (
    <div
      className="card card-body pnl-workflow-workspace"
      ref={reactFlowWrapper}
    >
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onInit={setReactFlowInstance}
        onDrop={onDrop}
        onDragOver={onDragOver}
        onNodeClick={onNodeClick}
        onEdgeDoubleClick={onEdgeDoubleClick}
        minZoom={0.4}
        maxZoom={4}
        fitView
        connectionLineType={ConnectionLineType.SmoothStep}
        nodeTypes={WorkflowNodeType}
        edgeTypes={edgeType}
        deleteKeyCode={["Backspace", "Delete"]}
      >
        <Background color="#777" gap={16} />
        <Controls />
      </ReactFlow>

      {viewTree && (
        <div className="pnl-network-connect">
          <div className="card mb-0">
            <div className="card-header d-flex align-items-center">
              <h6 className="mb-0">SubModel 연결 정보</h6>
              <div className="d-inline-flex ms-auto">
                <div
                  className="text-body cursor-pointer"
                  onClick={onClickCloseTree}
                >
                  <i className="ph-x"></i>
                </div>
              </div>
            </div>
            <div className="card-body row">
              <div className="col d-column">
                <h6>Source</h6>
                <TreeView list={sourceTreeData} />
              </div>
              <div className="col d-column">
                <h6>Target</h6>
                <TreeView list={targetTreeData} />
              </div>
            </div>
          </div>
        </div>
      )}
      {expandProperty && (
        <div className="pnl-property">
          <PropertyPanel
            origin={selectedNode}
            handleModify={handleModifyProperty}
            closePanel={handleExpandProperty}
          ></PropertyPanel>
        </div>
      )}
    </div>
  );
});

export default Workflow;
