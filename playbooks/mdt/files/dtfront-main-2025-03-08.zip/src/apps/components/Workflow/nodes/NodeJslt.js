import { Handle, Position, useUpdateNodeInternals } from "@xyflow/react";
import { memo, useEffect, useState } from "react";
import clsx from "classnames";
import UtilManager from "apps/utils/util_manager";

const NodeJslt = ({ id, data, selected }) => {
  const updateNodeInternals = useUpdateNodeInternals();
  const { CONVERT_HANDLE_DATA } = UtilManager();

  const [item, setItem] = useState();
  const [fromlist, setFromlist] = useState([]);
  const [tolist, setTolist] = useState([]);

  const onClickSetting = () => {
    if (data.onShowNodeSetting) {
      console.log("Click Setting", data);

      data.onShowNodeSetting(id, data);
    }
  };

  const convertData = (item) => {
    setItem(item);

    let variable = item.variables;
    let result = CONVERT_HANDLE_DATA(id, variable);

    setFromlist(result.from);
    setTolist(result.to);
  };

  useEffect(() => {
    updateNodeInternals(id);
  }, [tolist, fromlist]);

  useEffect(() => {
    if (data && data.item) {
      convertData(data.item);
    }
  }, [data]);

  return (
    <div>
      <div className="pnl-expand-node">
        <div className="btn-node-setting">
          <button
            className="btn btn-default btn-icon btn-sm"
            onClick={onClickSetting}
          >
            <i className="ph-gear"></i>
          </button>
        </div>
        <div className="expand-node-wrapper">
          <div className="node-left">
            {fromlist.map((item, index) => (
              <Handle
                key={index}
                type="target"
                position={Position.Left}
                id={item.id}
                className="node-handle"
              >
                {item.name}
              </Handle>
            ))}
          </div>
          <div className="node-wrapper flex-fill">
          <div className="node-label">{item?.id || "NoName"}</div>
          <div className="task-label">{data?.label || ""}</div>
          </div>
          <div className="node-right">
            {tolist.map((item, index) => (
              <Handle
                key={index}
                type="source"
                position={Position.Right}
                id={item.id}
                className="node-handle"
              >
                {item.name}
              </Handle>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default memo(NodeJslt);
