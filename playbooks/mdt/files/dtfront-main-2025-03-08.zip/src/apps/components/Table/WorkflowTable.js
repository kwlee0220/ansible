import { dataTool } from "echarts";
import { useEffect, useRef, useState } from "react";
import ReactPaginate from "react-paginate";
import { Link } from "react-router-dom";
import EmptyList from "../EmptyList";
import modal_icon from "assets/images/logo/header_icon.png";
import UtilManager from "apps/utils/util_manager";
import useModal from "../modal/useModal";
import useRequestManager from "apps/utils/request_manager";
import ModalWorkflowInfo from "../modal/modal_workflow";

const WorkflowTable = () => {
  const { IS_INCLUDE } = UtilManager();

  const modalWorkflowInfo = useModal();
  const [selectedWorkflow, setSelectedWorkflow] = useState();

  const [pageCount, setPageCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(0);
  const [searchText, setSearchText] = useState("");

  const [startNum, setStartNum] = useState("-");
  const [endNum, setEndNum] = useState("-");
  const [totalNum, setTotalNum] = useState("-");

  const [originList, setOriginList] = useState([]);
  const [datalist, setDatalist] = useState([]);

  //#region 데이터 조회

  const { REQ_Workflow_GET_ALL } = useRequestManager();

  const fetchWorkflowALL = async () => {
    let result = await REQ_Workflow_GET_ALL();

    if (result) {
      setOriginList(result);
    }
  };

  //#endregion

  const FilterList = () => {
    let list = [...originList];

    if (searchText && searchText !== "") {
      list = list.filter((item) => {
        if (
          IS_INCLUDE(item.id, searchText) ||
          IS_INCLUDE(item.name, searchText) ||
          IS_INCLUDE(item.description, searchText)
        ) {
          return true;
        }
        return false;
      });
    }

    changePageStatus(list);
  };

  const changePageStatus = (list) => {
    const endOffset = (currentPage + 1) * 10;
    const start = currentPage * 10;

    var index_start = 1;
    var index_end = 1;

    index_start = currentPage * 10 + 1;
    index_end = (currentPage + 1) * 10;

    if (index_end > list.length) {
      index_end = list.length;
    }

    setStartNum(index_start);
    setEndNum(index_end);
    setTotalNum(list.length);

    setDatalist(list.slice(start, endOffset));
    setPageCount(Math.ceil(list.length / 10));
  };

  const handlePageClick = (e) => {
    setCurrentPage(e.selected);
  };

  useEffect(() => {
    fetchWorkflowALL();
  }, []);

  useEffect(() => {
    FilterList();
  }, [originList, currentPage]);

  return (
    <div>
      <div className="inner-title">
        <h4 className="mb-0">
          <img src={modal_icon} className="me-2" height={16}></img>Workflow 목록
        </h4>
        <div className="input-group" style={{ width: "340px" }}>
          <span className="input-group-text bg-transparent text-default">
            검색
          </span>
          <input
            type="text"
            className="form-control"
            placeholder="검색어를 입력해주세요"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
          ></input>
          <button
            className="btn btn-light btn-icon bg-transparent text-default"
            type="button"
            onClick={FilterList}
          >
            <i className="ph-magnifying-glass"></i>
          </button>
        </div>
      </div>
      <div className="table-responsive">
        <table
          style={{ width: "100%" }}
          className="table datatable-basic table-bordered"
        >
          <thead>
            <tr>
              <th>No</th>
              <th>ID</th>
              <th>Name</th>
              <th>Description</th>
              <th>Task</th>
              <th>관리</th>
            </tr>
          </thead>
          <tbody>
            {datalist && datalist.length > 0 ? (
              <>
                {datalist.map((item, index) => (
                  <tr key={"item-" + index}>
                    <td>{startNum + index}</td>
                    <td>{item.id}</td>
                    <td>{item.name}</td>
                    <td>{item.description}</td>
                    <td>
                      {item.tasks &&
                        item.tasks.map((task, idx) => (
                          <div key={idx}>
                            <div>{`${task.id} [ ${task.type} ] `}</div>
                          </div>
                        ))}
                    </td>
                    <td>
                      <button
                        type="button"
                        className="btn btn-success btn-icon me-1"
                        onClick={() => {
                          setSelectedWorkflow(item);
                          modalWorkflowInfo.toggleModal();
                        }}
                      >
                        <i className="ph-magnifying-glass"></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </>
            ) : (
              <tr>
                <td colSpan={6} className="p-0">
                  <EmptyList message={"조회된 데이터가 없습니다."}></EmptyList>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="d-flex justify-content-between mt-3">
        <div>
          Showing<span style={{ margin: "0px 2px" }}>{startNum}</span>to
          <span style={{ margin: "0px 2px" }}>{endNum}</span>of
          <span style={{ margin: "0px 2px" }}>{totalNum}</span>entries
        </div>
        <ReactPaginate
          breakLabel="..."
          nextLabel="next"
          forcePage={currentPage}
          onPageChange={handlePageClick}
          pageRangeDisplayed={5}
          pageCount={pageCount}
          previousLabel="prev"
          renderOnZeroPageCount={null}
          className="pagination pagination-flat align-self-center ms-auto"
          pageClassName="page-item"
          activeClassName="active"
          pageLinkClassName="page-link"
          previousClassName="page-item"
          nextClassName="page-item"
          previousLinkClassName="page-link"
          nextLinkClassName="page-link"
        ></ReactPaginate>
      </div>

      <ModalWorkflowInfo
        open={modalWorkflowInfo.open}
        closeModal={modalWorkflowInfo.toggleModal}
        data={selectedWorkflow}
      ></ModalWorkflowInfo>
    </div>
  );
};

export default WorkflowTable;
