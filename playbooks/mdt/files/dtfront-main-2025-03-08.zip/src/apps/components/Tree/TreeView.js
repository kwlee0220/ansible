import TreeNode from "./TreeNode";

const TreeView = ({ list = null, clickNode }) => {
  return (
    <div className="rounded py-3 flex-1">
      {list ? (
        <>
          {list.map((node) => (
            <TreeNode key={node.id} node={node} clickNode={clickNode} />
          ))}
        </>
      ) : (
        <></>
      )}
    </div>
  );
};

export default TreeView;
