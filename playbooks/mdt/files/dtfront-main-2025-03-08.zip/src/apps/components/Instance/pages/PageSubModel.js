import { useEffect, useState } from "react";
import modal_icon from "assets/images/logo/header_icon.png";
import SubModelTree from "../SubModelTree";
import useRequestManager from "apps/utils/request_manager";

const PageSubModel = ({ model, closeInfo }) => {
  const [modelInfo, setModelInfo] = useState();
  const [subModel, setSubModel] = useState();
  const [baseInfo, setBaseInfo] = useState();

  //#region 데이터 조회

  const { REQ_Node_SubModel_GET } = useRequestManager();

  const fetchSubModel = async (url, id) => {
    const encodeID = btoa(id);
    const path = url + "/submodels/" + encodeID + "?$value";

    let result = await REQ_Node_SubModel_GET({
      url: path,
    });

    if (result) {
      console.log("fetchSubModel", result);

      setModelInfo(result);

      if (result.submodelElements) {
        setSubModel(result.submodelElements);
      }
    }
  };

  //#endregion

  const makeData = (info) => {
    const { endPoint, model } = info;

    setBaseInfo(model);

    if (endPoint) {
      fetchSubModel(endPoint, model.id);
    }
  };

  useEffect(() => {
    if (model) {
      makeData(model);
    }
  }, [model]);

  return (
    <div>
      <div className="page-title">
        <img src={modal_icon}></img>
        <div className="title">SubModel 정보</div>
        <button
          className="btn btn-info btn-icon width-100 ms-auto"
          onClick={closeInfo}
        >
          <i className="ph-x me-2"></i>
          닫기
        </button>
      </div>

      <div className="contents-part mb-4">
        <div className="table-container">
          <table className="table mb-0">
            <thead>
              <tr>
                <td>기본정보</td>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <div className="row">
                    <label className="col-form-label col-2">ID</label>
                    <label className="col-form-label col-10 label-value">
                      {baseInfo ? baseInfo.id : ""}
                    </label>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div className="row">
                    <label className="col-form-label col-2">Short ID</label>
                    <label className="col-form-label col-10 label-value">
                      {baseInfo ? baseInfo.idShort : ""}
                    </label>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div className="row">
                    <label className="col-form-label col-2">Semantic ID</label>
                    <label className="col-form-label col-10 label-value">
                      {baseInfo ? baseInfo.semanticId : ""}
                    </label>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="contents-part">
        <div className="contents-title">
          <div className="title">
            <img src={modal_icon} className="me-2" height={16}></img>
            <span>SubModel 트리</span>
          </div>
        </div>
        <div className="table-container">
          <table className="table mb-0">
            <tbody>
              <tr>
                <td>
                  <SubModelTree data={subModel ? subModel : []}></SubModelTree>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PageSubModel;
