import {
  get_aas,
  get_submodel,
  get_node_relation_submodel,
  get_simulation,
  delete_simulation,
  get_instance,
  get_instance_all,
  start_instance,
  stop_instance,
  get_instance_ass_descriptor,
  get_instance_stderr,
  get_instance_stdout,
  get_instance_submodel_descriptors,
  req_login,
  get_users_all,
  get_users,
  post_users,
  put_users,
  delete_users,
  delete_instance,
  add_instance,

  // Workflow API
  add_workflow_template,
  start_workflow,
  get_workflow_template,
  get_workflow_template_all,
  get_workflow_all,
  get_workflow,
  suspend_workflow,
  resume_workflow,
  stop_workflow,
  delete_workflow,
  
  // Argo Workflow API
  argo_workflow_create,
  argo_workflow_delete,
  argo_workflow_get,  
  argo_workflow_lint,
  argo_workflow_list,
  argo_workflow_pod_logs,
  argo_workflow_resubmit,
  argo_workflow_resume,
  argo_workflow_retry,
  argo_workflow_set,
  argo_workflow_stop,
  argo_workflow_submit,
  argo_workflow_suspend,
  argo_workflow_terminate,
  argo_watch_events,
  argo_watch_workflows,
  argo_workflow_logs,
} from "apps/remote/urls";

const useRequestManager = () => {
  const GET_RESULT = (resp) => {
    let result = {
      error: "Error",
      status: resp.status,
      data: resp.data,
    };

    return result;
  };

  //#region Auth API

  const REQ_LOGIN = async (data) => {
    let result;

    try {
      const resp = await req_login(data);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_LOGIN ERROR", e.response);

        result = GET_RESULT(e.response);
      }
    }

    return result;
  };

  //#endregion

  //#region Users API

  const REQ_GET_USERS_ALL = async () => {
    let result;

    try {
      const resp = await get_users_all();
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_GET_USERS_ALL ERROR", e.response);

        result = GET_RESULT(e.response);
      }
    }

    return result;
  };

  const REQ_GET_USERS = async (userid) => {
    let result;

    try {
      const resp = await get_users(userid);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_GET_USERS ERROR", e.response);

        result = GET_RESULT(e.response);
      }
    }

    return result;
  };

  const REQ_POST_USERS = async (data) => {
    let result;

    try {
      const resp = await post_users(data);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_POST_USERS ERROR", e.response);

        result = GET_RESULT(e.response);
      }
    }

    return result;
  };

  const REQ_PUT_USERS = async (userid, data) => {
    let result;

    try {
      const resp = await put_users(userid, data);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_PUT_USERS ERROR", e.response);

        result = GET_RESULT(e.response);
      }
    }

    return result;
  };

  const REQ_DELETE_USERS = async (userid) => {
    let result;

    try {
      const resp = await delete_users(userid);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_DELETE_USERS ERROR", e.response);

        result = GET_RESULT(e.response);
      }
    }

    return result;
  };

  //#endregion

  //#region AAS API

  const REQ_AAS_GET = async (id) => {
    let result;

    try {
      const resp = await get_aas(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_AAS_GET ERROR", e.response);
      }
    }

    return result;
  };

  //#endregion

  //#region SubModel API

  const REQ_SubModel_GET = async (id) => {
    let result;

    try {
      const resp = await get_submodel(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_SubModel_GET ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Node_SubModel_GET = async (data) => {
    let result;

    try {
      const resp = await get_node_relation_submodel(data);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Node_SubModel_GET ERROR", e.response);
      }
    }

    return result;
  };

  //#endregion

  //#region Simulation API

  const REQ_Simulation_GET = async (param) => {
    let result;

    try {
      const resp = await get_simulation(param);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Simulation_GET ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Simulation_DELETE = async (id, opid) => {
    let result;

    try {
      const resp = await delete_simulation(id, opid);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Simulation_DELETE ERROR", e.response);
      }
    }

    return result;
  };

  //#endregion

  //#region Instance API

  const REQ_Instance_GET = async (id) => {
    let result;

    try {
      const resp = await get_instance(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_GET ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_GET_ALL = async () => {
    let result;

    try {
      const resp = await get_instance_all();
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_GET_ALL ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_START = async (id) => {
    let result;

    try {
      const resp = await start_instance(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_START ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_STOP = async (id) => {
    let result;

    try {
      const resp = await stop_instance(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_STOP ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_ADD = async (formData) => {
    let result;

    try {
      const resp = await add_instance(formData);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_ADD ERROR", e.response);
        const errorMessage = e.response.data?.message || 
                            e.response.data?.error || 
                            e.response.statusText || 
                            "인스턴스 추가 중 오류가 발생했습니다.";
        throw new Error(errorMessage);
      }
      throw e;
    }

    return result;
  };

  const REQ_Instance_DELETE = async (id) => {
    let result;

    try {
      const resp = await delete_instance(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_DELETE ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_GET_Submodel_Descriptors = async (id) => {
    let result;

    try {
      const resp = await get_instance_submodel_descriptors(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_GET_Submodel_Descriptors ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_GET_Ass_Descriptor = async (id) => {
    let result;

    try {
      const resp = await get_instance_ass_descriptor(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_GET_Ass_Descriptor ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_GET_Stdout = async (id) => {
    let result;

    try {
      const resp = await get_instance_stdout(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_GET_Stdout ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_GET_Stderr = async (id) => {
    let result;

    try {
      const resp = await get_instance_stderr(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_GET_Stderr ERROR", e.response);
      }
    }

    return result;
  };

  //#endregion

  //#region Workflow API

  const REQ_Workflow_GET_ALL = async () => {
    let result;

    try {
      const resp = await get_workflow_template_all();
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Workflow_GET_ALL ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Workflow_GET_INSTANCE_ALL = async () => {
    let result;

    try {
      const resp = await get_workflow_all();
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Workflow_GET_INSTANCE_ALL ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Workflow_GET = async (id) => {
    let result;
    try {
      const resp = await get_workflow_template(id);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Workflow_GET ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };


  const REQ_Workflow_ADD = async (data) => {
    let result;
    try {
      const resp = await add_workflow_template(data);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Workflow_Add ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Workflow_START = async (id) => {
    let result;
    try {
      const resp = await start_workflow(id);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Workflow_Start ERROR", e.response);
      }
    }
    return result;
  };

  const REQ_Workflow_SUSPEND = async (name) => {
    let result;
    try {
      const resp = await suspend_workflow(name);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Workflow_SUSPEND ERROR", e.response);
      }
    }
    return result;
  };

  const REQ_Workflow_RESUME = async (name) => {
    let result;
    try {
      const resp = await resume_workflow(name);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Workflow_RESUME ERROR", e.response);
      }
    }
    return result;
  };

  const REQ_Workflow_STOP = async (name) => {
    let result;
    try {
      const resp = await stop_workflow(name);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Workflow_STOP ERROR", e.response);
      }
    }
    return result;
  };

  const REQ_Workflow_DELETE = async (name) => {
    let result;
    try {
      const resp = await delete_workflow(name);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Workflow_DELETE ERROR", e.response);
      }
    }
    return result;
  };

  //#endregion

  //#region Workflow API V1
  const REQ_Argo_Workflow_Create = async (data) => {
    let result;
    try {
      const resp = await argo_workflow_create(data);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_Create ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Workflow_Delete = async (name, params) => {
    let result;
    try {
      const resp = await argo_workflow_delete(name, params);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_Delete ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Workflow_Get = async (name, params) => {
    let result;
    try {
      const resp = await argo_workflow_get(name, params);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_Get ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Workflow_Lint = async (data) => {
    let result;
    try {
      const resp = await argo_workflow_lint(data);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_Lint ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Workflow_List = async (params) => {
    let result;
    try {
      const resp = await argo_workflow_list(params);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_List ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Workflow_Pod_Logs = async (name, podName, params) => {
    let result;
    try {
      const resp = await argo_workflow_pod_logs(name, podName, params);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_Pod_Logs ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Workflow_Resubmit = async (name, data) => {
    let result;
    try {
      const resp = await argo_workflow_resubmit(name, data);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_Resubmit ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Workflow_Resume = async (name, data) => {
    let result;
    try {
      const resp = await argo_workflow_resume(name, data);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_Resume ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Workflow_Retry = async (name, data) => {
    let result;
    try {
      const resp = await argo_workflow_retry(name, data);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_Retry ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Workflow_Set = async (name, data) => {
    let result;
    try {
      const resp = await argo_workflow_set(name, data);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_Set ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Workflow_Stop = async (name, data) => {
    let result;
    try {
      const resp = await argo_workflow_stop(name, data);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_Stop ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Workflow_Submit = async (data) => {
    let result;
    try {
      const resp = await argo_workflow_submit(data);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_Submit ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Workflow_Suspend = async (name, data) => {
    let result;
    try {
      const resp = await argo_workflow_suspend(name, data);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_Suspend ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Workflow_Terminate = async (name, data) => {
    let result;
    try {
      const resp = await argo_workflow_terminate(name, data);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_Terminate ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Watch_Events = async (params) => {
    let result;
    try {
      const resp = await argo_watch_events(params);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Watch_Events ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Watch_Workflows = async (params) => {
    let result;
    try {
      const resp = await argo_watch_workflows(params);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Watch_Workflows ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  const REQ_Argo_Workflow_Logs = async (name, params) => {
    let result;
    try {
      const resp = await argo_workflow_logs(name, params);
      result = resp.data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Argo_Workflow_Logs ERROR", e.response);
        result = GET_RESULT(e.response);
      }
    }
    return result;
  };

  //---
  return {
    // Auth API
    REQ_LOGIN,

    // Users API
    REQ_GET_USERS_ALL,
    REQ_GET_USERS,
    REQ_POST_USERS,
    REQ_PUT_USERS,
    REQ_DELETE_USERS,

    REQ_AAS_GET,

    // Instance API
    REQ_Instance_GET,
    REQ_Instance_GET_ALL,
    REQ_Instance_START,
    REQ_Instance_STOP,
    REQ_Instance_ADD,
    REQ_Instance_DELETE,
    REQ_Instance_GET_Ass_Descriptor,
    REQ_Instance_GET_Submodel_Descriptors,
    REQ_Instance_GET_Stdout,
    REQ_Instance_GET_Stderr,
    REQ_Simulation_DELETE,
    REQ_Simulation_GET,
    REQ_SubModel_GET,

    // SubModel Info API
    REQ_Node_SubModel_GET,

    // Workflow API
    REQ_Workflow_GET_ALL,
    REQ_Workflow_GET_INSTANCE_ALL,
    REQ_Workflow_GET,
    REQ_Workflow_ADD,
    REQ_Workflow_START,
    REQ_Workflow_SUSPEND,
    REQ_Workflow_RESUME,
    REQ_Workflow_STOP,
    REQ_Workflow_DELETE,

    // Workflow API V1
    REQ_Argo_Workflow_Create,
    REQ_Argo_Workflow_Delete,
    REQ_Argo_Workflow_Get,
    REQ_Argo_Workflow_Lint,
    REQ_Argo_Workflow_List,
    REQ_Argo_Workflow_Pod_Logs,
    REQ_Argo_Workflow_Resubmit,
    REQ_Argo_Workflow_Resume,
    REQ_Argo_Workflow_Retry,
    REQ_Argo_Workflow_Set,
    REQ_Argo_Workflow_Stop,
    REQ_Argo_Workflow_Submit,
    REQ_Argo_Workflow_Suspend,
    REQ_Argo_Workflow_Terminate,
    REQ_Argo_Watch_Events,
    REQ_Argo_Watch_Workflows,
    REQ_Argo_Workflow_Logs,
    
  };
};

export default useRequestManager;
