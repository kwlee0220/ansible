#!	/bin/bash

java -cp $MDT_HOME/share/mdt-apps-all.jar welder.PredictTotalQuantity "$@"
