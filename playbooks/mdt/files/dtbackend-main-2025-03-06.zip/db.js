// db.js
const bcrypt = require("bcrypt");

//#region 테이블 생성 쿼리

// 사용자 테이블 쿼리
const query_create_users = `
      CREATE TABLE IF NOT EXISTS users (
        userid TEXT PRIMARY KEY NOT NULL,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        password TEXT NOT NULL,
        description TEXT,
        grade INTEGER DEFAULT 0 NOT NULL,
        regdate TEXT DEFAULT (DATETIME(CURRENT_TIMESTAMP, '+9 hours'))
      )
    `;

//#endregion

const sqlite3 = require("sqlite3").verbose();
const path = require("path");

// SQLite 데이터베이스 연결
const dbPath = path.resolve(__dirname, "manager.db");
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error("Error opening database:", err.message);
  } else {
    console.log("Connected to the SQLite database.");

    // 초기 테이블 생성
    db.run(query_create_users, async (err) => {
      if (err) {
        console.error("사용자 테이블 생성 오류 :", err.message);
      } else {
        console.log("사용자 테이블이 생성되었습니다.");

        const query = `INSERT OR IGNORE INTO users (userid, name, email, password, description, grade)
         VALUES (?, ?, ?, ?, ?, ?)`;
        const hashedPassword = await bcrypt.hash("etri", 10);

        db.run(query, [
          "admin",
          "관리자",
          "manager@etri.re.kr",
          hashedPassword,
          "초기 등록 관리자",
          1,
        ]);
      }
    });
  }
});

module.exports = db;
