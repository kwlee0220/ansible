const express = require("express");
const router = express.Router();
const userModel = require("../queries/userQuery");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const SECRET_KEY = "etri_mdt_instance";

router.post("/login", (req, res) => {
  const { userid, password } = req.body;

  if (!userid || !password) {
    return res
      .status(400)
      .json({ error: "사용자 아이디와 비밀번호를 입력해주세요." });
  }

  userModel.loginUser(userid, password, (data) => {
    if (data) {
      if (data.status === 200) {
        const token = jwt.sign({ userid: userid }, SECRET_KEY, {
          expiresIn: "1h",
        });
        data.token = token;
      }

      res.status(data.status).json(data);
    } else {
      res.status(400).json({ error: "처리중 에러발생" });
    }
  });
});

// 사용자 추가 (Create)
router.post("/", async (req, res) => {
  let body = req.body;

  const hashedPassword = await bcrypt.hash(body.password, 10);

  body.password = hashedPassword;

  userModel.addUser(body, (err) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.status(201).json({ result: true });
    }
  });
});

// 모든 사용자 정보 조회 (Read)
router.get("/", (req, res) => {
  userModel.getUsers((err, users) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json(users);
    }
  });
});

// 특정 사용자 정보 조회 (Read)
router.get("/:id", (req, res) => {
  const { id } = req.params;

  userModel.getUserById(id, (err, user) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else if (user) {
      res.json(user);
    } else {
      res.status(404).json({ error: "User not found" });
    }
  });
});

// 사용자 정보 수정 (Update)
router.put("/:id", (req, res) => {
  const { id } = req.params;
  let body = req.body;

  userModel.updateUser(id, body, (err, changes) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else if (changes === 0) {
      res.status(404).json({ error: "User not found" });
    } else {
      res.json({ message: "User updated successfully" });
    }
  });
});

// 사용자 삭제 (Delete)
router.delete("/:id", (req, res) => {
  const { id } = req.params;

  userModel.deleteUser(id, (err, changes) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else if (changes === 0) {
      res.status(404).json({ error: "User not found" });
    } else {
      res.json({ message: "User deleted successfully" });
    }
  });
});

module.exports = router;
