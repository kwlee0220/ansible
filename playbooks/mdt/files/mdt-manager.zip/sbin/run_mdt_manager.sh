#!	/bin/bash

(cd $MDT_HOME/mdt-manager; java -jar mdt-manager-all.jar)
