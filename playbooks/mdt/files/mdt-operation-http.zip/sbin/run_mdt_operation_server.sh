#!	/bin/bash

(cd $MDT_HOME/mdt-operation-http; java -jar mdt-operation-http.jar)
