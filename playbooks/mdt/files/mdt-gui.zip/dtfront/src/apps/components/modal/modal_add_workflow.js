import { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import modal_icon from "assets/images/logo/header_icon.png";
import JsonView from "../Instance/LogView";

const ModalAddWorkflow = ({ origin, open, closeModal, handleAdd, handleExec }) => {
  const [inputs, setInputs] = useState({
    id: "",
    name: "",
    description: "",
    tasks: [],
  });

  const [tasks, setTasks] = useState();

  const handleChangeInput = (e) => {
    const { name, value } = e.target;

    setInputs({
      ...inputs,
      [name]: value,
    });
  };

  const onClickAdd = () => {
    // TODO -- etri updated
    let workflow = {
      id: inputs.id,
      name: inputs.name,
      description: inputs.description,
      tasks: JSON.parse(tasks),
    };

    handleAdd(workflow);
    //---
  };

  const convertData = (data) => {
    setTasks(JSON.stringify(data, null, 2));
    setInputs({
      ...inputs,
      tasks: data,
    });
  };

  const onClickExec = () => {
    if (handleExec && origin) {
        let workflow = {
            id: inputs.id,
            name: inputs.name,
            description: inputs.description,
            tasks: JSON.parse(tasks),
          };
         handleExec(workflow);
    }
  };

  useEffect(() => {
    if (origin && open) {
      convertData(origin);
    }
  }, [origin, open]);

  return (
    <Modal show={open} centered animation={false} size={"lg"}>
      <Modal.Header>
        <div className="header-icon">
          <i className="ph-app-window"></i>
        </div>
        <div className="modal-title">워크플로우 등록</div>
        <button
          type="button"
          className="btn btn-link ms-auto"
          onClick={closeModal}
        >
          <i className="ph-x"></i>
        </button>
      </Modal.Header>
      <Modal.Body>
        <div className="contents-part mb-4">
          <div className="table-container">
            <table className="table mb-0">
              <thead>
                <tr>
                  <td>기본정보</td>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <div className="row">
                      <label className="col-form-label col-2">ID</label>
                      <div className="col-10">
                        <input
                          type="text"
                          className="form-control"
                          name="id"
                          value={inputs ? inputs.id : ""}
                          onChange={handleChangeInput}
                        ></input>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div className="row">
                      <label className="col-form-label col-2">Name</label>
                      <div className="col-10">
                        <input
                          type="text"
                          className="form-control"
                          name="name"
                          value={inputs ? inputs.name : ""}
                          onChange={handleChangeInput}
                        ></input>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div className="row">
                      <label className="col-form-label col-2">
                        Description
                      </label>
                      <div className="col-10">
                        <input
                          type="text"
                          className="form-control"
                          name="description"
                          value={inputs ? inputs.description : ""}
                          onChange={handleChangeInput}
                        ></input>
                      </div>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="contents-part">
          <div className="contents-title">
            <div className="title">
              <img src={modal_icon} className="me-2" height={16}></img>
              <span>Tasks 정보</span>
            </div>
          </div>
          <div className="table-container">
            <table className="table mb-0">
              <tbody>
                <tr>
                  <td>
                    <JsonView data={tasks ? tasks : ""}></JsonView>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <button className="btn btn-default me-2" onClick={onClickAdd}>
          Workflow 등록
        </button>
        <button className="btn btn-default me-2" onClick={onClickExec}>
          Workflow 실행
        </button>
        <button className="btn btn-link" onClick={closeModal}>
          닫기
        </button>
      </Modal.Footer>
    </Modal>
  );
};

export default ModalAddWorkflow;
