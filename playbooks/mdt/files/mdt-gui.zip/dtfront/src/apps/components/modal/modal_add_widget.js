import { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import useModal from "./useModal";
import ModalSelectProperty from "./modal_select_prop";
import MDTTreeView from "../common/MDTTreeView";
import ImagePreview from "../common/ImagePreview";
import SubModelView from "../common/SubModelTreeView";
import UtilManager from "apps/utils/util_manager";
import useCommon from "apps/hooks/useCommon";

const variable = {
  name: "",
  type: "table",
  size: "1",
  link: "",
  interval: "5",
  params: "",
  description: "",
  etc: "",
  data: null,
};

const ModalAddWidget = ({
  widget,
  open,
  closeModal,
  handleAddWidget,
  handleUpdateWidget,
}) => {
  const { IS_NULL } = UtilManager();
  const { instanceList } = useCommon();

  const [listLink, setListLink] = useState([]);
  const [inputData, setInputData] = useState({});
  const [error, setError] = useState(null);

  const [showDetail, setShowDetail] = useState("table");

  const convertData = (data) => {
    let info = JSON.parse(data.widget);

    setShowDetail(info.type);
    setInputData(info);
  };

  const handleAdd = () => {
    try {
      if (IS_NULL(inputData.name)) {
        setError("위젯명을 입력해주세요.");
        return;
      }
      if (IS_NULL(inputData.type)) {
        setError("위젯 타입을 선택해주세요.");
        return;
      }
      if (IS_NULL(inputData.size)) {
        setError("사이즈를 선택해주세요.");
        return;
      }

      switch (inputData.type) {
        case "value":
        case "chart":
        case "image":
          if (IS_NULL(inputData.link)) {
            setError("데이터 조회를 위한 링크를 입력해주세요.");
            return;
          }
          break;
        case "tree":
          if (IS_NULL(inputData.instance)) {
            setError("MDT 인스턴스를 선택해주세요.");
            return;
          }
          break;
      }
    } catch (err) {
      setError(err.message || "등록 중 오류가 발생했습니다.");
    }

    if (widget) {
      if (handleUpdateWidget) {
        handleUpdateWidget(inputData);
      }
    } else {
      if (handleAddWidget) {
        handleAddWidget(inputData);
      }
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setInputData({
      ...inputData,
      [name]: value,
    });

    if (name === "type") {
      setShowDetail(value);
    }

    setError(null);
  };

  const handleChangeImage = (img) => {
    setInputData({
      ...inputData,
      params: img,
    });
  };

  const handleSelectedLink = (path) => {
    setInputData({
      ...inputData,
      link: path,
    });
  };

  useEffect(() => {
    if (open) {
      if (widget) {
        convertData(widget);
      } else {
        setInputData(variable);
        setListLink([]);
      }
      setError(null);
    }

    return () => {
      setInputData(variable);
      setError(null);
      setShowDetail("table");
      setListLink([]);
    };
  }, [open, widget]);

  return (
    <>
      <Modal
        show={open}
        centered
        animation={false}
        size={
          showDetail === "value" ||
          showDetail === "image" ||
          showDetail === "chart"
            ? "xl"
            : ""
        }
      >
        <Modal.Header>
          <div className="header-icon">
            <i className="ph-app-window"></i>
          </div>
          <div className="modal-title">위젯 {widget ? "변경" : "추가"}</div>
          <button
            type="button"
            className="btn btn-link ms-auto"
            onClick={closeModal}
          >
            <i className="ph-x"></i>
          </button>
        </Modal.Header>
        <div className="row">
          <div className="col">
            <div className="card card-input mb-0">
              <table className="table table-border mb-0">
                <colgroup>
                  <col style={{ width: "140px" }}></col>
                  <col></col>
                </colgroup>
                <tbody>
                  <tr>
                    <td>위젯명</td>
                    <td>
                      <input
                        type="text"
                        className="form-control"
                        name="name"
                        value={inputData ? inputData.name : ""}
                        onChange={handleInputChange}
                      ></input>
                    </td>
                  </tr>
                  <tr>
                    <td>위젯타입</td>
                    <td>
                      <select
                        className="form-select"
                        name="type"
                        value={inputData ? inputData.type : "table"}
                        onChange={handleInputChange}
                      >
                        <option value="value">값</option>
                        <option value="table">테이블</option>
                        <option value="chart">차트</option>
                        <option value="tree">트리</option>
                        <option value="image">이미지</option>
                      </select>
                    </td>
                  </tr>
                  <tr>
                    <td>패널사이즈</td>
                    <td>
                      <select
                        className="form-select"
                        name="size"
                        value={inputData ? inputData.size : "1"}
                        onChange={handleInputChange}
                      >
                        <option value="1">전체</option>
                        <option value="1/2">1/2</option>
                        <option value="1/3">1/3</option>
                        <option value="1/4">1/4</option>
                      </select>
                    </td>
                  </tr>
                  {(showDetail === "value" || showDetail === "image") && (
                    <tr>
                      <td>조회링크</td>
                      <td>
                        <div className="input-group">
                          <input
                            type="text"
                            className="form-control"
                            name="link"
                            value={inputData ? inputData.link : ""}
                            readOnly
                          ></input>
                        </div>
                      </td>
                    </tr>
                  )}
                  {showDetail === "chart" && (
                    <tr>
                      <td>조회링크</td>
                      <td>
                        <div className="input-group">
                          <input
                            type="text"
                            className="form-control"
                            name="link"
                            value={inputData ? inputData.link : ""}
                            readOnly
                          ></input>
                          <button className="btn btn-light">
                            <i className="ph-plus"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  )}
                  {(showDetail === "value" || showDetail === "chart") && (
                    <tr>
                      <td>조회주기</td>
                      <td>
                        <div className="input-group">
                          <input
                            type="text"
                            className="form-control"
                            name="interval"
                            value={inputData ? inputData.interval : ""}
                            onChange={handleInputChange}
                          ></input>
                          <span className="input-group-text">초</span>
                        </div>
                      </td>
                    </tr>
                  )}
                  {showDetail === "tree" && (
                    <tr>
                      <td>MDT 인스턴스</td>
                      <td>
                        <div className="input-group">
                          <select
                            className="form-select"
                            name="etc"
                            value={inputData ? inputData.etc : ""}
                            onChange={handleInputChange}
                          >
                            <option value="">Select Instance</option>
                            {instanceList &&
                              instanceList.length > 0 &&
                              instanceList.map((item, index) => (
                                <option value={item.id}>
                                  {item.aasIdShort}
                                </option>
                              ))}
                          </select>
                        </div>
                      </td>
                    </tr>
                  )}

                  <tr>
                    <td>설명</td>
                    <td>
                      <textarea
                        name="description"
                        className="form-control"
                        value={inputData ? inputData.description : ""}
                        onChange={handleInputChange}
                        rows={5}
                      ></textarea>
                    </td>
                  </tr>
                </tbody>
              </table>
              {error && (
                <div className="alert alert-danger m-3" role="alert">
                  {error}
                </div>
              )}
            </div>
          </div>
          {showDetail === "value" ||
          showDetail === "image" ||
          showDetail === "chart" ? (
            <div className="col">
              <div className="pnl-widget-tree">
                <MDTTreeView
                  handlePropertyLinkChange={handleSelectedLink}
                ></MDTTreeView>
              </div>
            </div>
          ) : (
            <></>
          )}
        </div>
        <Modal.Footer>
          <button className="btn btn-success" onClick={handleAdd}>
            {widget ? "변경" : "추가"}
          </button>
          <button className="btn btn-link" onClick={closeModal}>
            닫기
          </button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default ModalAddWidget;
