import { useEffect } from "react";

const CreateInstance = () => {
  useEffect(() => {}, []);

  return <div></div>;
};

export default CreateInstance;
