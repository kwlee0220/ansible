#!	/bin/bash

java -cp $MDT_HOME/models/mdt-apps-all.jar welder.PredictTotalThroughput
