#!	/bin/bash

cd $HOME/development/mdtpy/mdt-welder && python3 scripts/append_ampere_record.py data/23.05.25.csv "$@"
