#!	/bin/bash

java -cp $HOME/development/mdt/mdt-apps/build/libs/mdt-apps-1.1.2-all.jar welder.PredictTotalThroughput
