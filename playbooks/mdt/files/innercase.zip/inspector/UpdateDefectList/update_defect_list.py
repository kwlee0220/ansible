import argparse
import re

def extract_defects_from_file(file_path):
    with open(file_path, 'r') as file:
        content = file.read().strip()
        # Extract the list of 1s and 0s
        defect_pattern = re.findall(r'[01]', content)
        return [int(value) for value in defect_pattern]

def determine_defect(defect_data):
    """
    defect_data: List of integers where 1 represents a defect and 0 represents a non-defect.
    Returns '1' if any defect (1) is found, otherwise '0'.
    """
    return '1' if any(defect_data) else '0'

if __name__ == '__main__':
    # Argument parsing
    parser = argparse.ArgumentParser(description="Defect Determination and Result Saving")
    parser.add_argument("Defect", type=str, help="Path to first defect data file")
    parser.add_argument("DefectList", type=str, help="Path to second defect data file")
    parser.add_argument("--output", type=str, help="Output file for combined result", required=True)
    args = parser.parse_args()

    # Extract defect data from the first file
    defect_data_1 = extract_defects_from_file(args.Defect)
    # Determine if there is a defect
    defect_result = determine_defect(defect_data_1)

    # Read the contents of the second file and add the defect result
    with open(args.DefectList, 'r') as file:
        content_2 = file.read().strip()

    # Append the defect result to the second file's content
    combined_result = content_2.split(',')
    combined_result.append(defect_result)
    if len(combined_result) > 20:
        combined_result = combined_result[len(combined_result)-20:]
    combined_result = ','.join(combined_result)

    print("(Input)  Defect: ", defect_data_1)
    print("(Input)  DefectList: ", content_2)
    print("(Result) DefectList: ", combined_result)

    # Output the combined result to the specified output file
    with open(args.output, "w") as out:
        out.write(combined_result)
