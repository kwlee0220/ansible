#!	/bin/bash

minikube start --memory=no-limit --cpus=no-limit
