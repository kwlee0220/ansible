#!	/bin/bash

minikube start --memory=no-limit --cpus=no-limit
kubectl create rolebinding default-admin --clusterrole=admin --serviceaccount=argo:default -n argo
