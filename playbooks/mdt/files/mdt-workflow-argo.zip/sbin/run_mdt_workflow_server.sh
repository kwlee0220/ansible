#!	/bin/bash

(cd $MDT_HOME/mdt-workflow-argo; java -jar mdt-workflow-argo.jar)
