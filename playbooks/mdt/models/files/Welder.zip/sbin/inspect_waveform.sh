#!	/bin/bash

cd $HOME/development/mdtpy/mdt-welder && python3 scripts/inspect_waveform.py --instance Welder "$@"
