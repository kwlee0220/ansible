#!	/bin/bash

cd $HOME/development/mdtpy/mdt-welder && python3 scripts/create_schema.py "$@"
