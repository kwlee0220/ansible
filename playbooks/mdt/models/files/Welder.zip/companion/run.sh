PYTHONPATH=$PYTHONPATH:$HOME/development/mdtpy/mdt-welder
python3 $HOME/development/mdtpy/mdt-welder/scripts/inspect_waveform.py --instance $1 --interval $2
