#!	/bin/bash

java -cp $MDT_HOME/models/mdt-apps-all.jar lg.inspector.InspectorCompanion --dir $HOME/tmp/inspector --fileRef param:inspector:UpperImage
